<?php
$con=mysqli_connect('localhost','root','','leads');
if(!$con)
{
echo "error in db connection";
}
?>